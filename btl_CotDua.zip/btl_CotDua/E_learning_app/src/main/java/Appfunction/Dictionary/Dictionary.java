package Appfunction.Dictionary;

public class Dictionary {
    private
    public void showAllWords() {

    }
}

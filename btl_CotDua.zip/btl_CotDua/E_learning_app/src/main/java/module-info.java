module org.example.e_learning_app {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires com.almasb.fxgl.all;

    opens org.example.e_learning_app to javafx.fxml;
    exports org.example.e_learning_app;
}